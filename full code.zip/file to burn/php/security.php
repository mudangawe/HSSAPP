<?php

include 'connect.php';
//Get the input request parameters
//$inputJSON = file_get_contents('php://input');
//$input = json_decode($inputJSON, TRUE); //convert JSON into array

file_put_contents('color.txt',$_POST['device']);
if(isset($_POST['device']) && !empty(isset($_POST['device'])))
{
  $id = "I was here";
 file_put_contents('ted.txt',$id);
	
	$device = $_POST['device'];
	
	$query    = "SELECT Device_Number FROM Device WHERE Device_Number = '$device'";
	
    $result = $con->query($query); 
  if ($result->num_rows > 0) 
  { 
    echo "LoginSuccess"; 
  } 
  else { 
    echo "Error: " . $sql . "<br>" . $conn->error; 
  }
}
else
{
    echo "Input Error"; 
}

?>