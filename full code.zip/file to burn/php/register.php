<?php

include 'connect.php';
include 'fuctions.php';
 

//Check for Mandatory parameters
if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['name']) && 
     isset($_POST['surname']) && isset($_POST['email']) && isset($_POST['contact'])){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$name = $_POST['name'];
		$email = $_POST['email'];
		$surname = $_POST['surname'];
		$contact = $_POST['contact'];
	//Check if user already exist
	   //if(!userExists($username)){
	 
	
			$insertQuery  = "INSERT INTO users(username, name, surname, contact,email,password) VALUES (?,?,?,?,?)";
			if($stmt = $con->prepare($insertQuery)){
				$stmt->bind_param("ssss",$username,$name,$surname,$contact,$email,$password);
				$stmt->execute();
				
				echo "User created";
				$stmt->close();
	//}
	
	
	}
	else
	{
		
		echo "Missing mandatory parameters";
	}
	
?>
