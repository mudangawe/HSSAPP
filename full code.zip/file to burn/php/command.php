
<?php

include 'connect.php';
//Get the input request parameters
//$inputJSON = file_get_contents('php://input');
//$input = json_decode($inputJSON, TRUE); //convert JSON into array


if(isset($_POST['command']) && !empty(isset($_POST['command'])))
{
       file_put_contents('command.txt',$_POST['command']);
       
}
else
{
    file_put_contents('command.txt','z');
    echo "Input Error"; 
}
exit();

?>