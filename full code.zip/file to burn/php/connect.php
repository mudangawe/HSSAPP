﻿
<?php

$con = mysqli_connect("localhost", "root", "password", "id1857399_hss");
// Check connection
if(mysqli_connect_errno())
{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//echo json_encode($response);
?>

