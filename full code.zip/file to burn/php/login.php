<?php

include 'connect.php';


error_reporting(E_ALL);
ini_set('display_errors', 1);
if(isset($_POST['username']) && !empty(isset($_POST['username'])) 
  && isset($_POST['password']) && !empty(isset($_POST['password']))){ 
    file_put_contents('ted.txt',$_POST['username']);
    $userName = $_POST['username']; 
    $password = $_POST['password'];
    $query    = "SELECT full_name,password FROM member WHERE username = s";     
    $sql = "SELECT username, PASWORD FROM Users 
          WHERE username = '$userName' AND PASWORD = '$password'"; 
    $result = $con->query($sql); 
  if ($result->num_rows > 0) { 
    echo "LoginSuccess"; 
  } 
  else { 
    echo "Error: " . $sql . "<br>" . $conn->error; 
  }

}
else
{
echo "recheck your login data";
}
?>
