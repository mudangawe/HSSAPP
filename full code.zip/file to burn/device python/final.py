import time
import itertools
import pigpio
import RPi.GPIO as GPIO
import urllib.request
import picamera

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

gate = True
door = True
alarmOn= True
GPIO_TRIGGER = 21
GPIO_ECHO = 20
alarm = 25
delayDoor =10
delay =2
gpios = [4, 17, 27, 22]
doorPios = [5, 6, 13, 19]

GPIO.setup(23, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(alarm, GPIO.OUT)
GPIO.setup(GPIO_TRIGGER, GPIO.OUT)
GPIO.setup(GPIO_ECHO, GPIO.IN)
camera = picamera.PiCamera()
pi=pigpio.pi()

if not pi.connected:
   exit(0)
   
x =0



class stepper:
   """
   A class to pulse a stepper.
   """

   def __init__(self, pi, g1, g2, g3, g4):
      """
      """
      self.pi = pi
      self.g1 = g1
      self.g2 = g2
      self.g3 = g3
      self.g4 = g4

      self.all = (1<<g1 | 1<<g2 | 1<<g3 | 1<<g4)

      self.pos = 0

      pi.set_mode(g1, pigpio.OUTPUT)
      pi.set_mode(g2, pigpio.OUTPUT)
      pi.set_mode(g3, pigpio.OUTPUT)
      pi.set_mode(g4, pigpio.OUTPUT)

   def move(self):
      pos = self.pos 
      if pos < 0:
         pos = 7
      elif pos > 7:
         pos = 0
      self.pos = pos

      if   pos == 0: on = (1<<self.g4)
      elif pos == 1: on = (1<<self.g3 | 1<<self.g4)
      elif pos == 2: on = (1<<self.g3)
      elif pos == 3: on = (1<<self.g2 | 1<<self.g3)
      elif pos == 4: on = (1<<self.g2)
      elif pos == 5: on = (1<<self.g1 | 1<<self.g2)
      elif pos == 6: on = (1<<self.g1)
      else:          on = (1<<self.g1 | 1<<self.g4)

      off = on ^ self.all

      self.pi.clear_bank_1(off)
      self.pi.set_bank_1(on)

   def forward(self):
      self.pos += 1
      self.move()

   def backward(self):
      self.pos -= 1
      self.move()

   def stop(self):
      self.pi.clear_bank_1(self.all)
      
      
#distance sensor
def distance():
    # set Trigger to HIGH
    GPIO.output(GPIO_TRIGGER, True)
  
    # set Trigger after 0.01ms to LOW
    time.sleep(0.00001)
    GPIO.output(GPIO_TRIGGER, False)
 
    StartTime = time.time()
    StopTime = time.time()
 
    # save StartTime
    while GPIO.input(GPIO_ECHO) == 0:
        StartTime = time.time()
 
    # save time of arrival
    while GPIO.input(GPIO_ECHO) == 1:
        StopTime = time.time()
 
    # time difference between start and arrival
    TimeElapsed = StopTime - StartTime
    # multiply with the sonic speed (34300 cm/s)
    # and divide by 2, because there and back
    distance = (TimeElapsed * 34300) / 2
 
    return distance

#main operation


try:
    d = stepper(pi, gpios[0], gpios[1], gpios[2], gpios[3])
    g = stepper(pi, doorPios[0], doorPios[1], doorPios[2], doorPios[3])
    if __name__ == '__main__':
        while True:
            dist = distance()
            print ("Measured Distance = %.1f cm" % dist)
            time.sleep(1)
            if dist < 34:
                GPIO.output(alarm, True)
                    
            input_state = GPIO.input(23)
            print('Button Pressed' + str(x))
            if input_state == False:
                x =x+1
                print('Button Pressed' + str(x))
                camera.start_preview()
                time.sleep(2)
                camera.capture('/var/www/html/image/image.jpg')
                camera.stop_preview()   
                time.sleep(0.2)
            f = open("/var/www/html/command.txt", "r")
            z = open("/var/www/html/gate.txt", "r")
            if f.mode == 'r':
               contents = f.read()
               conte = z.read()
               #contents = 'g'
            
               if contents == 'g':
                  stop = time.time() + delay
                  if(gate == True):
                      while time.time() < stop:
                        d.backward()
                        time.sleep(0.001)
                        gate = False
                  else:
                       while time.time() < stop:
                           d.forward()
                           time.sleep(0.001)
                           gate = True
                  f.close()
                    #I'm guessing this would output the html source code?
                  GPIO.output(alarm, False)
                 
                   
               if contents == 'a'  or conte == 'a':
                    if(alarmOn == True):
                      GPIO.output(alarm, True)
                      alarmOn = False
                    else:
                      GPIO.output(alarm, False)
                      alarmOn = True
               if contents == 'd':
                   stop = time.time() + delayDoor
                   if(door == True):
                      while time.time() < stop:
                        g.backward()
                        time.sleep(0.001)
                        door = False
                   else:
                       while time.time() < stop:
                          g.forward()
                          time.sleep(0.001)
                          door = False
                   f.close()
                  
                    #I'm guessing this would output the html source code?
                   
               with urllib.request.urlopen("http://localhost/command.php") as url:
                       s = url.read()
                     
except KeyboardInterrupt:
  GPIO.cleanup()